"""
Package version.

Replaced at build time.
"""

__version__ = "0.0.0"
