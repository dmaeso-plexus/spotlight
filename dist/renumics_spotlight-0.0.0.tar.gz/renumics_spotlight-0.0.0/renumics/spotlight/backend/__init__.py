"""
    This module provides all backend code.
    Based on FastAPI
"""
