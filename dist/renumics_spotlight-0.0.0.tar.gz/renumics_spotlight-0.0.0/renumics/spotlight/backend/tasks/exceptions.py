"""
Exceptions for task management
"""


class TaskCancelled(Exception):
    """
    The Task has been cancelled
    """
